Slide-a-Key: Cricut Print Then Cut Kit
======================================

These files let a Cricut cut the Pocket and Sleeve Editions, and the
add-ons, for you.
Design Space sends each piece, with its sensor marks, to your own
printer (inkjet or laser). The Cricut then reads the marks and cuts
around each piece, including any windows and the small centre holes
in the Pocket pieces. Made for a Cricut Maker 3; any machine that does
Print Then Cut should work.

The same instructions, with pictures of each piece, are in
slide-a-key_cricut_kit_instructions.pdf.

Files and their exact sizes (width x height)
--------------------------------------------
  pocket_base_card.png   9.88 x 9.88 cm    (square, small centre hole)
                         3.89 x 3.89 in
  pocket_top_disk.png    6.52 x 6.52 cm    (circle, small centre hole)
                         2.57 x 2.57 in
  pocket_chord_arm.png   6.79 x 9.44 cm    (optional add-on: three windows,
                         2.67 x 3.72 in     small centre hole)
  sleeve_sleeve.png      8.26 x 10.16 cm   (flap and window, upright)
                         3.25 x 4.00 in
  sleeve_slider.png      3.53 x 18.91 cm   (long strip, upright)
                         1.39 x 7.44 in
  sleeve_chord_strip.png 3.53 x 18.91 cm   (optional add-on: 24 windows,
                         1.39 x 7.44 in     upright)
  classic_chord_cursor.png
                         6.77 x 3.88 cm    (optional add-on: 8 windows and
                         2.67 x 1.53 in     a fold-over flap)

Design Space works in centimetres or inches; use whichever it's set to.

The sizes matter: if a piece is even slightly too big or small, the notes
won't line up. Always type in the exact size (cm or inches).

Step by step (Cricut Design Space)
----------------------------------
1. Upload > Upload Image, and choose one of the PNG files. Keep it as a
   Print Then Cut image (not a cut-only image). The background outside
   each piece is already transparent, so Design Space finds the cut line
   itself.
2. Add it to the canvas. With the lock closed, type the width from the
   list above. Check the height matches too.
3. Make It. When asked, turn "Add bleed" on. Print with your printer set
   to 100% scale (no "fit to page"), on plain matte paper or light
   cardstock. Glossy paper can stop the sensor reading the marks.
4. Put the printed sheet on a LightGrip mat, choose Light Cardstock (or
   your paper type) and let the machine cut.

Notes
-----
* Sensor marks: Design Space adds the black registration marks around
  the pieces by itself. They must be on the printed side.
* Chord arm, chord strip and chord cursor: optional add-ons that mark
  the three main chords (I, IV and V). Their windows are framed by narrow strips
  of paper, so light cardstock works better than thin paper. The
  chord strip's 24 windows are where the Cricut saves the most work.
* Centre holes: the Pocket pieces get a 3 mm hole for the brass paper
  fastener, so there's no need to poke one.
* Folds: the Sleeve's and the cursor's fold lines are printed. Fold along them by hand,
  or score them first with a ruler and an empty pen.
* If the cuts are a little off the printed edges, run Print Then Cut
  Calibration once from the Design Space menu.
* Assembly: follow each piece's sheet at
  www.slideakey.com. You'll also need a brass paper fastener for the
  Pocket, and glue for the Sleeve.

Free to print and share. Please don't sell. Licence: CC BY-NC 4.0.
www.slideakey.com
