Slide-a-Key: Cricut Print Then Cut Kit
======================================

These files let a Cricut cut the Pocket and Sleeve Editions, and the
add-ons, for you.
Design Space sends each piece, with its sensor marks, to your own
printer (inkjet or laser). The Cricut then reads the marks and cuts
around each piece, including any windows and the small centre holes
in the Pocket pieces and the Chord Family Pocket. Made for a Cricut Maker 3; any machine that does
Print Then Cut should work.

The same instructions, with pictures of each piece, are in
slide-a-key-cricut-kit-instructions.pdf.

Files and their exact sizes (width x height)
--------------------------------------------
  slide-a-key-pocket-transposer-base.png
                         9.88 x 9.88 cm    (square, small centre hole)
                         3.89 x 3.89 in
  slide-a-key-pocket-transposer-disk.png
                         6.52 x 6.52 cm    (circle, small centre hole)
                         2.57 x 2.57 in
  slide-a-key-sleeve-transposer-sleeve.png
                         8.26 x 12.38 cm   (flap and window, upright)
                         3.25 x 4.88 in
  slide-a-key-sleeve-transposer-slider.png
                         3.53 x 21.13 cm   (long strip, upright)
                         1.39 x 8.32 in
  slide-a-key-classic-chord-family-add-on.png
                         10.76 x 4.20 cm   (optional add-on: one window and
                         4.24 x 1.65 in     a fold-over flap)
  slide-a-key-pocket-chord-family-add-on.png
                         4.73 x 4.73 cm    (optional add-on: circle, small
                         1.86 x 1.86 in     centre hole)
  slide-a-key-sleeve-chord-family-add-on.png
                         13.44 x 8.54 cm   (optional add-on: one window and
                         5.29 x 3.36 in     a glue flap)

Design Space works in centimetres or inches; use whichever it's set to.
The sizes are for the piece itself. Each image has a thin transparent
border around it.

The sizes matter: if a piece is even slightly too big or small, the notes
won't line up. Always type in the exact size (cm or inches).

Step by step (Cricut Design Space)
----------------------------------
1. Upload > Upload Image, and choose one of the PNG files. Keep it as a
   Print Then Cut image (not a cut-only image). The background outside
   each piece is already transparent, so Design Space finds the cut line
   itself.
2. Add it to the canvas. With the lock closed, type the width from the
   list above. Check the height matches too.
3. Make It. When asked, turn "Add bleed" on. Print with your printer set
   to 100% scale (no "fit to page"), on plain matte paper or light
   cardstock. Glossy paper can stop the sensor reading the marks.
4. Put the printed sheet on a LightGrip mat, choose Light Cardstock (or
   your paper type) and let the machine cut.

Notes
-----
* Sensor marks: Design Space adds the black registration marks around
  the pieces by itself. They must be on the printed side.
* Chord Family Classic, Chord Family Pocket, and Chord Family Sleeve: optional add-ons that
  mark the main chords (I, IV, V, and vi). Light cardstock makes them
  sturdier.
* Centre holes: the Pocket pieces and the Chord Family Pocket get a 3 mm hole for the brass paper
  fastener, so there's no need to poke one.
* Folds: the fold lines on the Sleeve, Chord Family Classic, and Chord Family Sleeve are printed.
  Fold along them by hand, or score them first with a ruler and an empty pen.
* If the cuts are a little off the printed edges, run Print Then Cut
  Calibration once from the Design Space menu.
* Assembly: follow each piece's sheet at
  www.slideakey.com. You'll also need a brass paper fastener for the
  Pocket, and glue for the Sleeve.

Free to print and share. Please don't sell. Licence: CC BY-NC 4.0.
www.slideakey.com
